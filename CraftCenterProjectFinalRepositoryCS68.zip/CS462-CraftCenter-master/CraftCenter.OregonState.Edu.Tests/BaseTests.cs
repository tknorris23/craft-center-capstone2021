﻿using System;
using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;
using NSubstitute;

namespace CraftCenter.OregonState.Edu.Tests
{
    public class BaseTests
    {
        private const string LocalSqlServerConnectionString = @"Data Source=.;Initial Catalog=MVC-CraftCenter;Trusted_Connection=true;";
        
        protected readonly string inMemoryConnectionStringBase = "Server=(localdb)\\mssqllocaldb;Database=EFProviders.InMemory.{0};Trusted_Connection=True;ConnectRetryCount=0";

        protected ISettingsProvider SettingsProvider;

        public BaseTests()
        {
            SettingsProvider = Substitute.For<ISettingsProvider>();
            SettingsProvider.DbConnectionString.Returns(LocalSqlServerConnectionString);
        }

        protected DatabaseContext CreateInMemoryDbContext(string uniqueDatabaseName = "")
        {
            var dbName = string.IsNullOrEmpty(uniqueDatabaseName) ? Guid.NewGuid().ToString() : uniqueDatabaseName;
            var inMemoryConnectionString = string.Format(inMemoryConnectionStringBase, dbName);
            var options = new DbContextOptionsBuilder()
                .UseInMemoryDatabase(inMemoryConnectionString)
                .Options;
            var context = SetupSqlServerDbContext(o => new DatabaseContext(o, SettingsProvider), false, false, options);
            
            return context;
        }

        protected DatabaseContext CreateSqlServerDbContext(bool deleteIfDataBaseExists = false, bool enableSqlLogging = false)
        {
            var context = SetupSqlServerDbContext(
                o => new DatabaseContext(o, SettingsProvider),
                deleteIfDataBaseExists,
                enableSqlLogging);

            return context;
        }

        private DatabaseContext SetupSqlServerDbContext(Func<DbContextOptions, DatabaseContext> createContext, bool deleteDataBaseFirstIfThere,
            bool enableSqlLogging = false,
            DbContextOptions optionsOverride = null)
        {
            var options = optionsOverride ?? GetDbContextOptions(enableSqlLogging);
            var context = createContext(options);
            if (deleteDataBaseFirstIfThere)
            {
                context.Database.EnsureDeleted();
            }
            context.Database.EnsureCreated(); // creates schema but doesn't use migrations
            
            return context;
        }

        private DbContextOptions GetDbContextOptions(bool enableSqlLogging)
        {
            var builder = new DbContextOptionsBuilder()
                .UseSqlServer(LocalSqlServerConnectionString)
                .EnableSensitiveDataLogging();

            if (enableSqlLogging)
            {
                builder.UseLoggerFactory(Utilities.GetLoggerFactory());
            }

            return builder.Options;
        }
    }
}