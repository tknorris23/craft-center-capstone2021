﻿using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.DataAccess
{
    public interface IDbUnitOfWork
    {
        IDatabaseContext Context { get; }

        int Save();

        Task<int> SaveAsync();
    }
}