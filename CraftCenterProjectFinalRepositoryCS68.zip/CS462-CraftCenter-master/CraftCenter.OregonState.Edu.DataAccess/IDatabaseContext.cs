﻿using System.Threading;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.DataAccess
{
    public interface IDatabaseContext
    {
        DbSet<User> Users { get; set; }

        DbSet<Category> Categories { get; set; }

        DbSet<Course> Courses { get; set; }

        DbSet<Section> Sections { get; set; }

        DbSet<Membership> Memberships { get; set; }

        DbSet<Enrollment> Enrollments { get; set; }

        int SaveChanges();

        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}