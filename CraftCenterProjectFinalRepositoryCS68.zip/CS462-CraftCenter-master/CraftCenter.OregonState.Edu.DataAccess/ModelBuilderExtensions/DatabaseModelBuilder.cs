﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.DataAccess.ModelBuilderExtensions
{
    //todo:  create Repository layer with unit of work...
    public static class DatabaseModelBuilder
    {
        public static void BuildTableRelations(this ModelBuilder modelBuilder)
        {
            BuildUserDataTable(modelBuilder);
            BuildCourseTable(modelBuilder);
            BuildSectionTable(modelBuilder);
            BuildCategoryTable(modelBuilder);
            BuildMembershipTable(modelBuilder);
        }

        private static void BuildMembershipTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Membership>();

            entity
                .HasKey(m => m.Id);
        }

        private static void BuildUserDataTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<User>();

            entity
                .HasKey(u => u.Id);
        }

        private static void BuildCategoryTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Category>();

            entity
                .HasKey(x => x.CategoryId);

#if DEBUG
            //temporary data used during development efforts that should be removed before going to production.  
            entity.HasData(GetCategoryData());
#endif
        }

        private static void BuildCourseTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Course>();

            entity
                .HasKey(c => c.CourseId);

            entity
                .HasOne<Category>()
                .WithMany(x => x.Courses)
                .HasForeignKey(x => x.CategoryId);

#if DEBUG
            //temporary data used during development efforts that should be removed before going to production.  
            entity.HasData(GetCourseData());
#endif
        }

        private static void BuildSectionTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Section>();

            entity
                .HasKey(s => s.SectionId);

            entity
                .HasOne<Course>()
                .WithMany(x => x.Sections)
                .HasForeignKey(x => x.CourseId);

#if DEBUG
            entity.HasData(GetSectionData());
#endif
        }

        private static IEnumerable<Category> GetCategoryData()
        {
            return new List<Category>
            {
                new Category
                {
                    CategoryId = 1,
                    Name = "Ceramics",
                    isActive = true,
                    Description = "https://craftcenter.oregonstate.edu/classes/ceramics"
                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Fiber Arts",
                    isActive=true,
                    Description = "https://craftcenter.oregonstate.edu/classes/fiber-arts"
                },
            };
        }

        private static IEnumerable<Course> GetCourseData()
        {
            return new List<Course>
            {
                new Course
                {
                    CourseId = 1,
                    CategoryId = 1,
                    Name = "Ceramics Orientation",
                    Fee = 0,
                    isActive=true,
                    LengthInMinutes = 30
                },
                new Course
                {
                    CourseId = 2,
                    CategoryId = 2,
                    Name = "Sewing Studio Orientation",
                    Fee = 120,
                    isActive=true,
                    LengthInMinutes = 75
                }
            };
        }

        private static IEnumerable<Section> GetSectionData()
        {
            return new List<Section>
            {
                new Section {SectionId = 1, CourseId = 1, isActive=true, Name = "Ceramics Orientation I", Instructor = "Foster Farm"},
                new Section {SectionId = 2, CourseId = 1, isActive=true, Name = "Ceramics Orientation II ", Instructor = "Daffy Duck"},
                new Section {SectionId = 3, CourseId = 2, isActive=true, Name = "Sewing Studio Orientation I", Instructor = "Sheep Pig"},
                new Section {SectionId = 4, CourseId = 2,isActive=true, Name = "Sewing Studio Orientation II", Instructor = "Farmer John"}
            };
        }
    }
}