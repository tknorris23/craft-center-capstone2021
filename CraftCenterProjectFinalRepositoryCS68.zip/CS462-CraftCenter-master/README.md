# CS462-CraftCenter

## Description
This web application automates the membership and class registration processes for the OSU Craft Center. 

The OSU Craft Center is located in the Student Experience Center. The Craft Center provides people with the opportunity and environment to learn art, be creative, and use art materials and machinery that are available. Although the Craft Center is part of the university, the services are open to fee-paying and non-fee-paying OSU students, faculty and staff, OSU affiliates, and the general public. The Craft Center allows people to do many different types of art, such as ceramics, woodworking, paper art, jewelry, and photography. 

Currently, the Craft Center does all of its tasks and processes on paper. This results in problems and the need for staff to always be around at the front desk to help people who want to take advantage of the art resources. This has not been an efficient way to complete the tasks. For instance, the Craft Center requires paperwork for membership registration, locker rentals, class registration, and class orientations. Many times, the paperwork needs to be updated, which adds an extra manual step. All of this takes too much time and requires labor that can be automated.

The purpose of this web application is to make it easier for OSU students to take advantage of the Craft Center resources without having to go to the physical location to register for membership and courses. A student can register from the comfort of their dorm room, on their way to class, or wherever they choose. Also, this web application allows the administrators to manage existing memberships and edit the course catalog with ease. This will change the efficiency of the Craft Center for both students and employees of the Craft Center. This new tool for the Craft Center will be familiar to every user, as the user interface and features are similar to what is used today when registering for Facebook, managing online accounts, or signing up for classes online, right here at OSU. With a couple clicks of a button, students have access to all the creativity they could want from their college campus.

## Necessary Tools
- Visual Studio (the IDE that is used to work with ASP.NET Core)
- MS SQL Server (the relational database management system used)
- SQL Server Management Studio (SSMS) - (the corresponding software application for MS SQL Server to configure and manage the components of the database)
- Git (the chosen software to track changes in the code)
- GitHub (the chosen version control software)

## Optional Tools
- Fork or a similar git client to easily track all git commands and branches

## How to Build
1. Ensure that you have installed Visual Studio, MS SQL Server, and SSMS. If you have not installed MS SQL Server, follow these steps:
    -  Download MS SQL Server for your OS.
    -  Install the software.
    -  Once installed, click on installation and go to "New SQL Server stand-alone intallation or add features to an existing installation."
    -  Once clicked, check the updates box. 
    -  Click next until you reach the new installation. Check the default instance box. 
    -  Click next until you reach Database Engine Configuration. Click "Add Current User." This takes your local account and adds you as a server administrator.
    -  In Feature Selection, select the following:
          Database Engine Services, Client SDK Tools, SQL CLient Connectivity SDK, Full-Text and Semantic Extractions for Search
    -  For more information, [watch this video](https://media.oregonstate.edu/media/t/1_on3tdec6).
2. Open Visual Studio and clone this project in a new project. 
3. In Visual Studio, go to NuGet Package Manager and ensure that the following packages are install:
    -  AspNetSaml
    -  AutoMapper
    -  bootstrap
    -  coverlet.collector
    -  FluentAssertions
    -  ITfoxtec.Identity.Saml2
    -  ITfoxtec.Identity.Saml2.MvcCore
    -  Microsoft.AspNetCore.Authentication
    -  Microsoft.AspNetCore.Authentication.Facebook
    -  Microsoft.AspNetCore.Authentication.Google
    -  Microsoft.EntityFrameworkCore
    -  Microsoft.EntitityFrameworkCore.Design
    -  Microsoft.EntityFrameworkCore.InMemory
    -  Microsoft.EntityFrameworkCore.Proxies
    -  Microsoft.EntityFrameworkCore.SqlServer
    -  Microsoft.EntityFrameworkCore.Tools
    -  Microsoft.Extensions.Logging.Console
    -  Microsoft.NET.Test.Sdk
    -  Microsoft.VisualStudio.Web.CodeGeneration.Design
    -  MSTest.TestAdapter
    -  MSTEST.TestFramework
 4. In the server explorer, connect to your local database. 
 5. Open the Package Manager Console. Make sure that the startup project and default project are set to the DataAccess project. In the console, first type Drop-Database. Enter "Y". Then type Remove-Database. Then type Add-Migration CreateTables. Finally, type Update-Database. This process will fill your database instance with the data within the migrations. (NOTE: These commands will have to be written in the Package Manager Console any time a change is made to the database) 
 6. Open SSMS and connect to your local desktop instance. Expand the databases tab and go to the database that corresponds to the project (i.e. MVC-CraftCenter). Here, you can look at the tables of the project database.
 7. To run the project locally, make sure your startup project is set back to the WebUI project. When running the project, IIS Express should be used. Click the green button to run the project.
 8.  The project should open on a local port in your browser. 
 
## How to Use the Project - Client Side
### As an admin
1. On the login page, sign in with your OSU account. Your email will be registered as having admin privileges. 
2. Once signed in, you can use the Manage Members page to view, edit, and delete members. 
3. You can view the appearance of pages just as how a student would see them, such as registering for membership, classes, the FAQ page, and the profile page.
### As a student
1. On the login page, use the login option to sign in with your OSU account. 
2. Once logged in, you will be taken to the membership registration page. Enter in all of your information. If you skip a section, you will be shown an error until that section has been completed.
3. After registering for membership, you will be taken to the class registration page. Here you can pick your class type, course, and section. Make sure to fill out the necessary forms for those classes in the link provided. You then can register for the class. 
4. You will not be able to register as a member twice. Once you fill out the membership registration form, you will be taken to the Class Registration page and will not be able to access the Membership Registration page until you are deleted from the database. 
5. You can view your class list under the Your Classes page. 
6. If you have questions about the site, view the FAQ page. 
7. To look at your account details, go to the profile page. 

## File Navigation of Key Files
### Basic Repo Structure
#### Data Access Project
- DatabaseModelBuilder.cs: This file contains all of the functions to build the tables for the database. New tables are created here. 
- Create Tables Migration: This file shows all of the attributes and primary foreign keys for each table. This displays the structure of the database.
- MigrationNotes.txt: Refer to this file when needing to drop the database, remove or add migrations, and updating the database. 
- DatabaseContext: This file specifies which entities are included in the data model.
#### Domain Model Project
- This project contains model files for each of the database tables with all of their attributes.
#### Repository Project
- This project contains files that act as queries for the database (i.e. GetCategory). This project is used by any file that wants to access the data. A single repository is for each model. 
#### Services Project
- This project contains files that use the repository and applies added business logic. Repositories are injected into the services. Services can access multiple repository files and combine them. 
#### Tests Project
- This project contains test files for the repo. 
#### Web UI Project
- This project contains the controllers and views for all of the pages. Also, this project has the CSS files, shared layout file, SAML metadata files, and the startup file to configure the project's services.
### SAML Login Files
- CraftCenter.OregonState.Edu.WebUI/Controllers/AuthController.cs
- CraftCenter.OregonState.Edu.WebUI/Identity/ClaimsTransform.cs
- CraftCenter.OregonState.Edu.WebUI/Startup.cs
- CraftCenter.OregonState.Edu.WebUI/Views/Home/Index.cshtml 
- CraftCenter.OregonState.Edu.WebUI/Views/MembershipRegistration/Index.cshtml
- CraftCenter.OregonState.Edu.WebUI/appsettings.json 
- CraftCenter.OregonState.Edu.WebUI/wwwroot/SAML/idp-int-metadata.xml 
- CraftCenter.OregonState.Edu.WebUI/wwwroot/SAML/idp-metadata.xml 
- CraftCenter.OregonState.Edu.WebUI/wwwroot/SAML/idp-metadatasecond.xml
- Root/TestApp-Metadata.xml [This is the File that we have shared with OSU IAM for setting OSU SSO, if you change your App url you have to modify this xml and share it them again]
### Membership Registration Files
- CraftCenter.OregonState.Edu.Domain.Model/Membership.cs
- CraftCenter.OregonState.Edu.Repository/IMembershipRepository.cs 
- CraftCenter.OregonState.Edu.Repository/MembershipRepository.cs 
- CraftCenter.OregonState.Edu.Services/Requests/NewMembershipRequest.cs 
- CraftCenter.OregonState.Edu.Services/IMembershipServices.cs 
- CraftCenter.OregonState.Edu.Services/MembershipServices.cs 
- CraftCenter.OregonState.Edu.WebUI/Controllers/MembershipRegistrationController.cs 
- CraftCenter.OregonState.Edu.WebUI/Views/MembershipRegistration/Index.cshtml
### Class Registration Files
- CraftCenter.OregonState.Edu.DataAccess.csproj
- CraftCenter.OregonState.Edu.DataAccess/DatabaseContext.cs
- CraftCenter.OregonState.Edu.Domain.Model/Category.cs
- CraftCenter.OregonState.Edu.Domain.Model/Course.cs
- CraftCenter.OregonState.Edu.Domain.Model/Enrollment.cs
- CraftCenter.OregonState.Edu.Repository/ClassRegistrationRepository.cs
- CraftCenter.OregonState.Edu.Repository/EnrollmentRepository.cs
- CraftCenter.OregonState.Edu.Repository/IClassRegistrationRepository.cs
- CraftCenter.OregonState.Edu.Repository/IEnrollmentRepository.cs
- CraftCenter.OregonState.Edu.Repository/MembershipRepository.cs
- CraftCenter.OregonState.Edu.Services/ClassRegistrationService.cs
- CraftCenter.OregonState.Edu.Services/EnrollmentServices.cs
- CraftCenter.OregonState.Edu.Services/IClassRegistrationService.cs
- CraftCenter.OregonState.Edu.Services/IEnrollmentServices.cs
- CraftCenter.OregonState.Edu.WebUI/Controllers/ClassViewController.cs
- CraftCenter.OregonState.Edu.WebUI/Controllers/CourseRegistrationController.cs
- CraftCenter.OregonState.Edu.WebUI/Views/ClassView/Index.cshtml
- CraftCenter.OregonState.Edu.WebUI/Controllers/UserProfile.cs

### Admin Files
- CraftCenter.OregonState.Edu.WebUI/Controllers/AddClass.cs 
    -  The controller responsible for adding/editing classes.
- CraftCenter.OregonState.Edu.WebUI/Controllers/AdminController
    -  The controller reponsible for viewing/deleting/editing classes.
- CraftCenter.OregonState.Edu.WebUI/Views/AddClass/Index.cshtml 
    -  The view responsible for adding classes.
- CraftCenter.OregonState.Edu.WebUI/Views/Admin/Index.cshtml 
    -  The view responsible for viewing/deleting members.
- CraftCenter.OregonState.Edu.WebUI/Views/Admin/Edit.cshtml
    -  The view responsible for editing members.

## Future User Stories
For subsequent project builds, [this document](https://docs.google.com/document/d/1ttZiLKa2OSTZQH0WIUg-JfrY-UHWRWsI6xvsqRFQ0j4/edit?usp=sharing) can be used for future user stories that the Craft Center would like to have worked on. 
