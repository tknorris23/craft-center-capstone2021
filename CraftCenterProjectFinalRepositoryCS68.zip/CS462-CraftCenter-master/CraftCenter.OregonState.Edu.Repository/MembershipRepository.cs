﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Repository
{
    public class MembershipRepository : IMembershipRepository
    {
        private readonly IDatabaseContext dbContext;

        public MembershipRepository(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public void CreateMembership(Membership membership)
        {
            /*foreach (var Membership in dbContext.Memberships)
            {
                var OSUID = Membership.OsuId;
                if (membership.OsuId != OSUID)
                {
                    dbContext.Memberships.Add(membership);
                }
            }*/
            dbContext.Memberships.Add(membership);
        }

        public IEnumerable<Membership> getMembers()
        {
            return dbContext.Memberships.ToList();
        }

        public async Task<bool> CheckMemberShip(string EmailAddress)
        {
            bool CMember = false;
            List<Membership> getAllMembers = (List<Membership>)getMembers();
            foreach (Membership eachMember in getAllMembers)
            {
                if (eachMember.EmailAddress.ToString() == EmailAddress)
                {
                    CMember = true;
                }
            }
            return await Task.FromResult(CMember);
        }

        public async Task<Membership> ReturnMember(string EmailAddress)
        {
            List<Membership> getAllMembers = (List<Membership>)getMembers();
            foreach (Membership eachMember in getAllMembers)
            {
                if (eachMember.EmailAddress.ToString() == EmailAddress)
                {
                    return await Task.FromResult(eachMember);
                }
   
            }
            return await Task.FromResult<Membership>(null);
        }

       
    }
}
