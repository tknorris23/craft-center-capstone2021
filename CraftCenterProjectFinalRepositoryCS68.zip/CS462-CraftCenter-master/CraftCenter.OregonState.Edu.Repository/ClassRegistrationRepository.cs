﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.Repository
{
    public class ClassRegistrationRepository : IClassRegistrationRepository
    {
        private readonly IDatabaseContext dbContext;

        public ClassRegistrationRepository(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public IQueryable<int> GetAllCategoryIds()
        {
            return dbContext.Categories
                .Select(x => x.CategoryId)
                .Distinct();
        }
        public IQueryable<string> GetAllCategoryNames()
        {
            return dbContext.Categories
                .Select(x => x.Name)
                .Distinct();
        }

        public IQueryable<Category> GetCategory(int categoryId)
        {
            return dbContext.Categories
                .Include(x => x.Courses)
                .Where(x => x.CategoryId == categoryId);
        }

        public IQueryable<Category> GetAllCategories()
        {
            return dbContext.Categories.Distinct().Where(x => x.isActive==true);
        }

        public IQueryable<Category> GetCoursesByCategory(int categoryId)
        {
            //return dbContext.Courses
            //    .Where(x => x.CategoryId == categoryId);
            return dbContext.Categories
                .Include(x => x.Courses)
                .Where(x => x.CategoryId == categoryId).Where(x=>x.isActive==true);
        }

     
        
        public IQueryable<Course> GetCourse(int courseId)
        {
            return dbContext.Courses
                .Include(x => x.Sections)
                .Where(x => x.CourseId == courseId && x.isActive == true);
        }

        public IQueryable<Section> GetSections(int courseid)
        {
            return dbContext.Sections.Where(x => x.CourseId == courseid && x.isActive == true);
        }

        public IQueryable<Section> getSectionDetails(int sectionid)
        {
            Section SelectSection = new Section();
            SelectSection = dbContext.Sections.Find(sectionid);
            return dbContext.Sections.Where(x => x.SectionId == sectionid && x.isActive == true);
        }

        public IQueryable<Category> getCategoryDetails(int CategoryID)
        {
            return dbContext.Categories.Where(x => x.CategoryId == CategoryID && x.isActive == true);
        }

        public IQueryable<Course> getCourseDetails(int CourseID)
        {
            return dbContext.Courses.Where(x => x.CourseId == CourseID && x.isActive == true);
        }

        public Task<Section> findSection(int sectionid)
        {
            Section SelectSection = new Section();
            SelectSection = dbContext.Sections.Where(x => x.SectionId == sectionid && x.isActive == true).Single();
            if (SelectSection != null)
            {
                return Task.FromResult(SelectSection);
            }
            return Task.FromResult<Section>(null);
        }
        
        public Task<Course> findCourse(int courseID, int categoryID)
        {
            Course SelectCourse = new Course();
            SelectCourse = dbContext.Courses.Where(x => x.CourseId == courseID && x.isActive == true && x.CategoryId == categoryID).Single();
            if (SelectCourse != null)
            {
                return Task.FromResult(SelectCourse);
            }
            return Task.FromResult<Course>(null);
        }
        public Task<Category> findCategory(int categoryID)
        {
            IQueryable<Category> ourList = getCategoryDetails(categoryID);
            foreach (Category selectCategory in ourList)
            {
                if (selectCategory.CategoryId == categoryID && selectCategory.isActive==true)
                {
                    return Task.FromResult(selectCategory);
                }
            }
            return Task.FromResult<Category>(null);
        }
        public void CreateCategory(Category newCategory)
        {
            dbContext.Categories.Add(newCategory);
        }

        public void deleteCategory(int categoryID)
        {
            var removeCategory = dbContext.Categories.SingleOrDefault(item => item.CategoryId == categoryID);
            removeCategory.isActive = false;
            dbContext.Categories.Update(removeCategory);
        }

        public void addCourse(Course newCourse)
        {
            dbContext.Courses.Add(newCourse);
        }

        public void disableCourse(int courseID, int categoryID)
        {
            var disableCourse = dbContext.Courses.SingleOrDefault(item => item.CategoryId == categoryID && item.CourseId == courseID);
            disableCourse.isActive = false;
            dbContext.Courses.Update(disableCourse);
        }
        public void addSection(Section newSection)
        {
            dbContext.Sections.Add(newSection);
        }

        public void disableSection(int courseID, int categoryID, int sectionID)
        {
            var disableSection = dbContext.Sections.SingleOrDefault(item => item.SectionId == sectionID && item.CourseId == courseID);
            disableSection.isActive = false;
            dbContext.Sections.Update(disableSection); 
        }

        public void updateCategory(int categoryID, string categoryName, string categoryDescription)
        {
            var updateCategory = dbContext.Categories.SingleOrDefault(item => item.CategoryId == categoryID);
            updateCategory.Name = categoryName;
            updateCategory.Description = categoryDescription;
            dbContext.Categories.Update(updateCategory);
        }

        public void updateCourse(int categoryID, int courseID, string courseName, int courseFee, int courseLengthInMins, string courseCode, string courseDescription)
        {
            var updateCourse = dbContext.Courses.SingleOrDefault(item => item.CourseId == courseID && item.CategoryId == categoryID);
            updateCourse.Name = courseName;
            updateCourse.Fee = courseFee;
            updateCourse.LengthInMinutes = courseLengthInMins;
            updateCourse.Code = courseCode;
            updateCourse.Description = courseDescription;
            dbContext.Courses.Update(updateCourse);
        }

        public void updateSection(int courseID, int sectionID, string sectionName, string instructor, string type, string times, int maxEnrollment)
        {
            var updateSection = dbContext.Sections.SingleOrDefault(item => item.SectionId == sectionID && item.CourseId == courseID);
            updateSection.Name = sectionName;
            updateSection.Instructor = instructor;
            updateSection.Type = type;
            updateSection.Times = times;
            updateSection.MaxEnrl = maxEnrollment;
            dbContext.Sections.Update(updateSection);
        }

        public void updateSectionEnrollVal(int sectionID, int courseID)
        {
            var updateSection = dbContext.Sections.SingleOrDefault(item => item.SectionId == sectionID && item.CourseId == courseID);
            updateSection.ActualEnrl++;
            dbContext.Sections.Update(updateSection);
        }

        public IQueryable<Category> getDisabledCategories()
        {
            return dbContext.Categories.Where(x => x.isActive == false);
        }

        public void enableCategory(int categoryID)
        {
            var updateCategory = dbContext.Categories.SingleOrDefault(x => x.CategoryId== categoryID && x.isActive == false);
            updateCategory.isActive = true;
            dbContext.Categories.Update(updateCategory);
        }
        public IQueryable<Course> getDisabledCourses(int categoryID)
        {
            return dbContext.Courses.Where(x => x.CategoryId == categoryID && x.isActive == false);
        }
        public void enableCourse(int courseID, int categoryID)
        {
            var updateCourse = dbContext.Courses.SingleOrDefault(x => x.CategoryId == categoryID && x.CourseId == courseID && x.isActive == false);
            updateCourse.isActive = true;
            dbContext.Courses.Update(updateCourse);
        }
        public IQueryable<Section> getDisabledSections(int courseID)
        {
            return dbContext.Sections.Where(x => x.CourseId == courseID && x.isActive == false);
        }
        public void enableSection(int courseID, int categoryID, int sectionID)
        {
            var updateSection = dbContext.Sections.SingleOrDefault(item => item.SectionId == sectionID && item.CourseId == courseID && item.isActive == false);
            updateSection.isActive = true;
            dbContext.Sections.Update(updateSection);
        }
    }
}