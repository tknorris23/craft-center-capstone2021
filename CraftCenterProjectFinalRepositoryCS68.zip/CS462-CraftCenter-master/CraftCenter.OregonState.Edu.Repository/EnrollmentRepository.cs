﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Repository
{
    public class EnrollmentRepository : IEnrollmentRepository
    {
        private readonly IDatabaseContext dbContext;
        public EnrollmentRepository(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public bool CreateEnrollment(Enrollment enrollment)
        {
            bool createdNewEnrollment = false;
            List<Enrollment> getAllEnrollments = dbContext.Enrollments.ToList();
            if (getAllEnrollments.Count > 0)
            {
                foreach (var getEnrollment in getAllEnrollments)
                {
                    if (getEnrollment.CategoryID == enrollment.CategoryID && getEnrollment.CourseId == enrollment.CourseId && getEnrollment.SectionId == enrollment.SectionId && getEnrollment.MemberID == enrollment.MemberID)
                    {
                        return false;
                    }
                }
            }
            dbContext.Enrollments.Add(enrollment);
            createdNewEnrollment = true;
            return createdNewEnrollment;
        }
        public Task<List<Enrollment>> getUserEnrollment(int memberID)
        {
            List<Enrollment> listofClasses = new List<Enrollment>();
            List<Enrollment> ourEnrollments = dbContext.Enrollments.ToList();
            if (ourEnrollments.Count > 0)
            {
                foreach(Enrollment checkEnrollment in ourEnrollments)
                {
                    if (checkEnrollment.MemberID == memberID)
                    {
                        listofClasses.Add(checkEnrollment);
                    }
                }
                return Task.FromResult(listofClasses);
            }
        
            return Task.FromResult<List<Enrollment>>(null);
        }

        public IQueryable<Enrollment> getEnrollmentsbySection(int sectionID, int courseID, int categoryID)
        {
            return dbContext.Enrollments.Distinct().Where(x => x.CategoryID == categoryID && x.CourseId == courseID && x.SectionId == sectionID);
        }
    }
}
