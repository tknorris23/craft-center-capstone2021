﻿using CraftCenter.OregonState.Edu.Domain.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Repository
{
    public interface IMembershipRepository
    {
        void CreateMembership(Membership membership);
        IEnumerable<Membership> getMembers();
        Task<bool> CheckMemberShip(string EmailAddress);
        Task<Membership> ReturnMember(string EmailAddress);
    }
}