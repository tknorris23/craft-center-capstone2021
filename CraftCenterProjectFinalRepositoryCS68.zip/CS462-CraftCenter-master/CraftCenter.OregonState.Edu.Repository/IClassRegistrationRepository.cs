﻿using System.Linq;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.Domain.Model;

namespace CraftCenter.OregonState.Edu.Repository
{
    public interface IClassRegistrationRepository
    {
        //IQueryable<string> GetAllCourseCategories();
        
        IQueryable<int> GetAllCategoryIds();

        IQueryable<string> GetAllCategoryNames();

        IQueryable<Category> GetCategory(int categoryId);
        
        IQueryable<Category> GetAllCategories();

        //IQueryable<Course> GetCoursesByCategory(string category);

        //IQueryable<Course> GetCoursesByCategory(int categoryId);

        IQueryable<Category> GetCoursesByCategory(int categoryId);

        IQueryable<Course> GetCourse(int courseId);

        IQueryable<Section> GetSections(int courseid);

        IQueryable<Section> getSectionDetails(int sectionid);

        IQueryable<Category> getCategoryDetails(int CategoryID);
        IQueryable<Course> getCourseDetails(int CourseID);
        Task<Section> findSection(int sectionid);
        Task<Course> findCourse(int courseID, int categoryID);

        Task<Category> findCategory(int categoryID);

        void CreateCategory(Category newCategory);

        void deleteCategory(int categoryID);

        void addCourse(Course newCourse);

        void disableCourse(int courseID, int categoryID);

        void addSection(Section newSection);

        void disableSection(int courseID, int categoryID, int sectionID);

        void updateCategory(int categoryID, string categoryName, string categoryDescription);

        void updateCourse(int categoryID, int courseID, string courseName, int courseFee, int courseLengthInMins, string courseCode, string Description);

        void updateSection(int courseID, int sectionID, string sectionName, string instructor, string type, string time, int maxEnrollment);

        void updateSectionEnrollVal(int sectionID, int courseID);

        IQueryable<Category> getDisabledCategories();

        void enableCategory(int categoryID);

        IQueryable<Course> getDisabledCourses(int categoryID);

        void enableCourse(int courseID, int categoryID);

        IQueryable<Section> getDisabledSections(int courseID);
        void enableSection(int courseID, int categoryID, int sectionID);
    }
}