﻿using CraftCenter.OregonState.Edu.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Repository
{
    public interface IEnrollmentRepository
    {
        bool CreateEnrollment(Enrollment enrollment);
        Task<List<Enrollment>> getUserEnrollment(int memberID);

        IQueryable<Enrollment> getEnrollmentsbySection(int sectionID, int courseID, int categoryID);
    }
}
