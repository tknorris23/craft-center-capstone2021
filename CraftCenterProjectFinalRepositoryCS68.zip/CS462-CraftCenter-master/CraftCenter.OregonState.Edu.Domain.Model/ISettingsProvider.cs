﻿namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public interface ISettingsProvider
    {
        string DbConnectionString { get; }
        string GoogleClientId { get; }

        string GoogleClientSecret { get; }
    }
}