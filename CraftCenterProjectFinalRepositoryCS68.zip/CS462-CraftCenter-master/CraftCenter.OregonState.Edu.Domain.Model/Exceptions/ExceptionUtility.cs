﻿namespace CraftCenter.OregonState.Edu.Domain.Model.Exceptions
{
    public static class ExceptionUtility
    {
        public static void ThrowDomainObjectNotFoundException<T>(T foundObject, long id, string message = "")
        {
            if (foundObject != null) return;
            var additionalMsg = string.IsNullOrEmpty(message) ? string.Empty : $" {message.Trim()}";

            throw new DomainObjectNotFoundException(typeof(T), id, additionalMsg);
        }
    }
}