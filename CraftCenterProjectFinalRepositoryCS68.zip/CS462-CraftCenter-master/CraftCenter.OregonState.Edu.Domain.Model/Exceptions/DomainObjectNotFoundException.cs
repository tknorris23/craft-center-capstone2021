﻿using System;

namespace CraftCenter.OregonState.Edu.Domain.Model.Exceptions
{
    public class DomainObjectNotFoundException : Exception
    {
        public DomainObjectNotFoundException(string message)
            : base(message)
        {
        }

        public DomainObjectNotFoundException(Type domainObject, long id, string message = "")
            : base($"A '{domainObject.Name}' with the id = '{id}' was not found.{message}")
        {
        }
    }
}