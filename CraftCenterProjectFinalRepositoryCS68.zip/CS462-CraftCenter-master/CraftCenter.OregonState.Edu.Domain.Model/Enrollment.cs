﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Enrollment
    {
        public int EnrollmentID { get; set; }

        [ForeignKey("Membership")]
        public int MemberID { get; set; }
        public virtual Membership Membership { get; set; }

        [ForeignKey("Course")]
        public int CourseId { get; set; }
        public virtual Course Course { get; set; }

        [ForeignKey("Section")]
        public int? SectionId { get; set; }
        public virtual Section Section { get; set; }
        [ForeignKey("Category")]
        public int? CategoryID { get; set; }
        public virtual Category Category { get; set; }
    }
}
