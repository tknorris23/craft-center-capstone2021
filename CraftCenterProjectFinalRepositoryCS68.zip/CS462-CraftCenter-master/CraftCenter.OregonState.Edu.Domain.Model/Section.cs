﻿namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Section
    {
        public int SectionId { get; set; }

        public int CourseId { get; set; }

        public string Name { get; set; }

        public string Instructor { get; set; }

        public string Type { get; set; }

        public string Times { get; set; }

        public int ActualEnrl { get; set; }

        public bool isActive { get; set; }

        public int MaxEnrl { get; set; }
    }
}
