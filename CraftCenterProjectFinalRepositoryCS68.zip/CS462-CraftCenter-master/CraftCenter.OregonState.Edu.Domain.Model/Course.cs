﻿using System.Collections.Generic;

namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Course
    {
        public int CourseId { get; set; }

        public int CategoryId { get; set; }

        public string Name { get; set; }

        public int Fee { get; set; }

        public int LengthInMinutes { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }
        
        public bool isActive { get; set; }

        public virtual List<Section> Sections { get; set; }
    }
}