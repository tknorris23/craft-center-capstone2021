﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Repository;
using CraftCenter.OregonState.Edu.Services.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services
{
    public class MembershipServices : IMembershipServices
    {
        private readonly IMembershipRepository repository;
        private readonly IDbUnitOfWork unitOfWork;

        public MembershipServices(IDbUnitOfWork unitOfWork, IMembershipRepository repository)
        {
            this.repository = repository;
            this.unitOfWork = unitOfWork;
        }

        public async Task CreateMembership(NewMembershipRequest request)
        {
            var req = request;

            var memberShip = ServiceMapper.Mapper.Map<Membership>(request);

            repository.CreateMembership(memberShip);

            await unitOfWork.SaveAsync();
        }
        public IEnumerable<Membership> getMembers()
        {
            return repository.getMembers();
        }
        public async Task<bool> CheckMemberShip(string EmailAddress)
        {
            return await repository.CheckMemberShip(EmailAddress);
        }
        public async Task<Membership> ReturnMember(string EmailAddress)
        {
            return await repository.ReturnMember(EmailAddress);
        }

    }
}