﻿using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public interface IUserService
    {
        Task<User> SaveUserAsync(NewUserRequest request);
        Task<bool> CheckUser(NewUserRequest request);
    }
}