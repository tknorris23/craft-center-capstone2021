﻿namespace CraftCenter.OregonState.Edu.Services.Common
{
    public class CourseDto
    {

        public int CourseId { get; set; }

        public string Name { get; set; }

        public int Fee { get; set; }

        public int LengthInMinutes { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public bool isActive { get; set; }
    }
}