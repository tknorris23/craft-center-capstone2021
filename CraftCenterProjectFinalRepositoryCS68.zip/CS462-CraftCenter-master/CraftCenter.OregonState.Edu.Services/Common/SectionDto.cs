﻿namespace CraftCenter.OregonState.Edu.Services.Common
{
    public class SectionDto
    {
        public int SectionId { get; set; }

        public string Name { get; set; }

        public string Instructor { get; set; }

        public string Type { get; set; }

        public string Times { get; set; }

        public int ActualEnrl { get; set; }

        public bool isActive { get; set; }
        public int MaxEnrl { get; set; }

      
    }
}