﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public interface IMembershipServices
    {
        Task CreateMembership(NewMembershipRequest request);
        IEnumerable<Membership> getMembers();
        Task<bool> CheckMemberShip(string EmailAddress);
        Task<Membership> ReturnMember(string EmailAddress);
    }
}