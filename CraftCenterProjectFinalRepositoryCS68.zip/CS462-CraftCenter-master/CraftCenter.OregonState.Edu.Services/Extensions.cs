﻿using CraftCenter.OregonState.Edu.Domain.Model;
using System;
using System.Net;
using CraftCenter.OregonState.Edu.Domain.Model.Exceptions;

namespace CraftCenter.OregonState.Edu.Services
{
    public static class Extensions
    {
        public static (HttpStatusCode, string) GetCodeAndMessage(this Exception exception)
        {
            return exception switch
            {
                DomainObjectNotFoundException e => (HttpStatusCode.NotFound, e.Message),
                //list other exceptions here
                _ => (HttpStatusCode.InternalServerError, "An error occurred.  Check logging for details")
            };
        }
    }
}