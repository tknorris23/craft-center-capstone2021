﻿using AutoMapper;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services.Common;
using CraftCenter.OregonState.Edu.Services.Responses;
using System.Collections.Generic;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public static class ServiceMapper
    {
        static ServiceMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                SetupDomainModelToServiceLayer(cfg);

                SetupServiceLayerToDomainModel(cfg);
            });

            Mapper = config.CreateMapper();
        }

        public static IMapper Mapper { get; private set; }

        private static void SetupDomainModelToServiceLayer(IMapperConfigurationExpression cfg)
        {
            //Domain to DTO mapping
            cfg.CreateMap<Course, CourseDto>();

            cfg.CreateMap<Section, SectionDto>();

            cfg.CreateMap<Category, CategoryDto>();

            //Response mapping
            cfg.CreateMap<Category, GetCoursesResponse>()
                //.ForMember(response => response.Courses, opt => opt.MapFrom(c => c))
                //.ForMember(response => response.CategoryId, opt => opt.Ignore());
                .ForMember(response => response.Courses, opt => opt.MapFrom(x => x.Courses))
                .ForMember(response => response.CategoryName, opt => opt.MapFrom(x => x.Name))
                .ForMember(response => response.CategoryDescription, opt => opt.MapFrom(x => x.Description))
                .ForMember(response => response.CategoryId, opt => opt.Ignore());


            //cfg.CreateMap<List<string>, GetAllCourseCategoriesResponse>()
            //    .ForMember(response => response.Categories, opt => opt.MapFrom(x => x));

            cfg.CreateMap<List<Category>, GetAllCourseCategoriesResponse>()
                .ForMember(response => response.Categories, opt => opt.MapFrom(x => x));

            cfg.CreateMap<Course, GetScheduleResponse>()
                .ForMember(response => response.Sections, opt => opt.MapFrom(s => s.Sections))
                .ForMember(response => response.CourseName, opt => opt.MapFrom(c => c.Name));
            
        }

        private static void SetupServiceLayerToDomainModel(IMapperConfigurationExpression cfg)
        {
            cfg.CreateMap<NewMembershipRequest, Membership>();
            cfg.CreateMap<newCategoryRequest, Category>();
            cfg.CreateMap<newCourseRequest, Course>();
            cfg.CreateMap<newSectionRequest, Section>();
        }
    }
}
