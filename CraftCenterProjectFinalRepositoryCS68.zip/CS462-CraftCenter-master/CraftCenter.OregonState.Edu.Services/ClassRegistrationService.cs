﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Repository;
using CraftCenter.OregonState.Edu.Services.Responses;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using static CraftCenter.OregonState.Edu.Services.ServiceMapper;
using static CraftCenter.OregonState.Edu.Domain.Model.Exceptions.ExceptionUtility;
using System;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services.Requests;
using System.Linq;

namespace CraftCenter.OregonState.Edu.Services
{
    public class ClassRegistrationService : IClassRegistrationService
    {
        private readonly IDbUnitOfWork unitOfWork;
        private readonly IClassRegistrationRepository repository;

        public ClassRegistrationService(IDbUnitOfWork unitOfWork, IClassRegistrationRepository repository)
        {
            this.unitOfWork = unitOfWork;
            this.repository = repository;
        }

        public async Task<GetAllCourseCategoriesResponse> GetAllCategories()
        {
            var categories = await repository.GetAllCategories().ToListAsync();

            return Mapper.Map<GetAllCourseCategoriesResponse>(categories);
        }

        public async Task<GetCoursesResponse> GetCoursesByCategory(int categoryId)
        {
            var category = await repository.GetCoursesByCategory(categoryId)
                .SingleOrDefaultAsync();

            var response = Mapper.Map<GetCoursesResponse>(category);
            return response;
        }

        public async Task<GetScheduleResponse> GetSchedule(int courseId)
        {
            var course = await repository.GetCourse(courseId)
                .SingleOrDefaultAsync();

            ThrowDomainObjectNotFoundException(course, courseId);

            return Mapper.Map<GetScheduleResponse>(course);
        }
        public IQueryable<Section> GetSections(int courseid)
        {
            return repository.GetSections(courseid);
        }
        public async Task<Section> findSection(int sectionid)
        {
            return await repository.findSection(sectionid);
        }
        public async Task<Course> findCourse(int courseID, int categoryID)
        {
            return await repository.findCourse(courseID, categoryID);
        }
        public async Task<Category> findCategory(int categoryID)
        {
            return await repository.findCategory(categoryID);
        }
        public async Task addCategory(newCategoryRequest newRequest)
        {
            var req = newRequest;
            var Category = ServiceMapper.Mapper.Map<Category>(newRequest);
            repository.CreateCategory(Category);
            await unitOfWork.SaveAsync();
        }

        public async Task deleteCategory(int categoryID)
        {
            repository.deleteCategory(categoryID);
            await unitOfWork.SaveAsync();
        }

        public async Task addCourse(newCourseRequest newRequest)
        {
            var req = newRequest;
            var Course = ServiceMapper.Mapper.Map<Course>(newRequest);
            repository.addCourse(Course);
            await unitOfWork.SaveAsync();
        }

        public async Task disableCourse(int courseID, int categoryID)
        {
            repository.disableCourse(courseID, categoryID);
            await unitOfWork.SaveAsync();
        }
        
        public async Task addSection(newSectionRequest newRequest)
        {
            var req = newRequest;
            var Section = ServiceMapper.Mapper.Map<Section>(newRequest);
            repository.addSection(Section);
            await unitOfWork.SaveAsync();
        }

        public async Task disableSection(int courseID, int categoryID, int sectionID)
        {
            repository.disableSection(courseID, categoryID, sectionID);
            await unitOfWork.SaveAsync();
        }

        public async Task updateCategory(int categoryID, string categoryName, string categoryDescription)
        {
            repository.updateCategory(categoryID, categoryName, categoryDescription);
            await unitOfWork.SaveAsync();   
        }

        public async Task updateCourse(int categoryID, int courseID, string courseName, int courseFee, int courseLengthInMins, string courseCode, string courseDescription)
        {
            repository.updateCourse(categoryID, courseID, courseName, courseFee, courseLengthInMins, courseCode, courseDescription);
            await unitOfWork.SaveAsync();
        }

        public async Task updateSection(int courseID, int sectionID, string sectionName, string instructor, string type, string time, int maxEnrollment)
        {
            repository.updateSection(courseID, sectionID, sectionName, instructor, type, time, maxEnrollment);
            await unitOfWork.SaveAsync();
        }
        public async Task updateSectionEnrollVal(int sectionID, int courseID)
        {
            repository.updateSectionEnrollVal(sectionID, courseID);
            await unitOfWork.SaveAsync();
        }
        public IQueryable<Category> getDisabledCategories()
        {
            return repository.getDisabledCategories();
        }

        public async Task enableCategory(int categoryID)
        {
            repository.enableCategory(categoryID);
            await unitOfWork.SaveAsync();
        }
        public IQueryable<Course> getDisabledCourses(int categoryID)
        {
            return repository.getDisabledCourses(categoryID);
        }
        public async Task enableCourse(int courseID, int categoryID)
        {
            repository.enableCourse(courseID, categoryID);
            await unitOfWork.SaveAsync();
        }
        public IQueryable<Section> getDisabledSections(int courseID)
        {
            return repository.getDisabledSections(courseID);
        }
        public async Task enableSection(int courseID, int categoryID, int sectionID)
        {
            repository.enableSection(courseID, categoryID, sectionID);
            await unitOfWork.SaveAsync();
        }
    }
}