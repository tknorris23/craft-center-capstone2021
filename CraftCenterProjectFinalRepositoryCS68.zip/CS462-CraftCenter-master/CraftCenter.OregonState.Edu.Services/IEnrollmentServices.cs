﻿using CraftCenter.OregonState.Edu.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services
{
    public interface IEnrollmentServices
    {
        Task<bool> CreateEnrollment(Enrollment request);
        Task<List<Enrollment>> getUserEnrollment(int memberID);

        IQueryable<Enrollment> getEnrollmentsbySection(int sectionID, int courseID, int categoryID);
    }
}
