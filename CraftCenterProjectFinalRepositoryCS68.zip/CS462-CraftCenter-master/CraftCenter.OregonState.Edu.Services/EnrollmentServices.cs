﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public class EnrollmentServices : IEnrollmentServices
    {
        private readonly IEnrollmentRepository repository;
        private readonly IDbUnitOfWork unitOfWork;
        public EnrollmentServices(IDbUnitOfWork unitOfWork, IEnrollmentRepository repository)
        {
            this.repository = repository;
            this.unitOfWork = unitOfWork;
        }
        public async Task<bool> CreateEnrollment(Enrollment request)
        {
            bool registered = false;
            var req = request;
            var enrollment = ServiceMapper.Mapper.Map<Enrollment>(request);
            registered = repository.CreateEnrollment(enrollment);
            await unitOfWork.SaveAsync();
            return registered;
        }
        public async Task<List<Enrollment>> getUserEnrollment(int memberID)
        {
            return await repository.getUserEnrollment(memberID);
        }

        public IQueryable<Enrollment> getEnrollmentsbySection(int sectionID, int courseID, int categoryID)
        {
            return repository.getEnrollmentsbySection(sectionID, courseID, categoryID);
        }
    }
}
