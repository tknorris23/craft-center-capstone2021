﻿using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services
{
    using Responses;
    using CraftCenter.OregonState.Edu.Domain.Model;
    using CraftCenter.OregonState.Edu.Services.Requests;
    using System.Linq;

    public interface IClassRegistrationService
    {
        //Task<GetAllCourseCategoriesResponse> GetAllCourseCategories();

        Task<GetAllCourseCategoriesResponse> GetAllCategories();

        Task<GetCoursesResponse> GetCoursesByCategory(int categoryId);

        Task<GetScheduleResponse> GetSchedule(int courseId);

        IQueryable<Section> GetSections(int courseid);

        Task<Section> findSection(int sectionid);
        Task<Course> findCourse(int courseID, int categoryID);
        Task<Category> findCategory(int categoryID);
        Task addCategory(newCategoryRequest newRequest);

        Task deleteCategory(int categoryID);

        Task addCourse(newCourseRequest newRequest);


        Task disableCourse(int courseID, int categoryID);

        Task addSection(newSectionRequest newRequest);

        Task disableSection(int courseID, int categoryID, int sectionID);

        Task updateCategory(int categoryID, string categoryName, string categoryDescription);

        Task updateCourse(int categoryID, int courseID, string courseName, int courseFee, int courseLengthInMins, string courseCode, string courseDescription);

        Task updateSection(int courseID, int sectionID, string sectionName, string instructor, string type, string time, int maxEnrollment);

        Task updateSectionEnrollVal(int sectionID, int courseID);

        IQueryable<Category> getDisabledCategories();

        Task enableCategory(int categoryID);
        IQueryable<Course> getDisabledCourses(int categoryID);

        Task enableCourse(int courseID, int categoryID);
        IQueryable<Section> getDisabledSections(int courseID);

        Task enableSection(int courseID, int categoryID, int sectionID);
    }
}
