﻿namespace CraftCenter.OregonState.Edu.Services.Requests
{
    public class NewMembershipRequest
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string OsuId { get; set; }

        public string PhoneNumber { get; set; }

        public string EmailAddress { get; set; }

        public string RegistrationDate { get; set; }
        public string TypeRegistration { get; set; }
    }
}