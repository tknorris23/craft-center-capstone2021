﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services.Requests
{
   public  class newSectionRequest
    {
        public int CourseId { get; set; }

        public string Name { get; set; }

        public string Instructor { get; set; }

        public string Type { get; set; }

        public string Times { get; set; }

        public int ActualEnrl { get; set; }

        public bool isActive { get; set; }

        public int MaxEnrl { get; set; }
    }
}
