﻿using CraftCenter.OregonState.Edu.Domain.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services.Requests
{
    public class NewEnrollmentRequest
    {
        [ForeignKey("Membership")]
        public int MemberID { get; set; }
        public Membership Membership { get; set; }

        [ForeignKey("Course")]
        public int CourseID { get; set; }
        public Course Course { get; set; }

        [ForeignKey("Section")]
        public int? SectionID { get; set; }
        public Section Section { get; set; }
        [ForeignKey("Category")]
        public int? CategoryID { get; set; }
        public Category Category { get; set; }
    }
}
