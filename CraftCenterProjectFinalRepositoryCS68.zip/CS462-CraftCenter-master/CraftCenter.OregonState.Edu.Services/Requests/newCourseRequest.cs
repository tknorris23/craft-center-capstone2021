﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services.Requests
{
    public class newCourseRequest
    {
        public int CategoryId { get; set; }

        public string Name { get; set; }

        public int Fee { get; set; }

        public int LengthInMinutes { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public bool isActive { get; set; }
    }
}
