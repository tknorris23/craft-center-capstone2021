﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Services.Requests;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccess;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.Services
{
    public class UserService : IUserService
    {
        private readonly IDatabaseContext dbContext;

        public UserService(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }
        
        public async Task<User> SaveUserAsync(NewUserRequest request)
        {
            var user = new User
            {
                EmailAddress = request.EmailAddress,
                Issuer = request.Issuer,
                Name = request.Name,
                Role = request.UserRole,
                ClaimIdentifier = request.ClaimIdentifier
            };

            List<User> userslist = new List<User>();
            userslist = await GetUsers();
     
            await dbContext.Users.AddAsync(user);
            await dbContext.SaveChangesAsync();

            return user;
        }

        public async Task<List<User>> GetUsers()
        {
            List<User> userslist = new List<User>();
             userslist = await dbContext.Users.ToListAsync();
            return userslist;
        }

        public async Task<bool> CheckUser(NewUserRequest request)
        {
            bool CheckUser = false;
            List<User> userslist = new List<User>();
            userslist = await GetUsers();
            foreach (User uservar in userslist)
            {
                if (uservar.EmailAddress.ToString() == request.EmailAddress.ToString())
                {
                    CheckUser = true;
                }
            }
            if (CheckUser == true)
            {
                return await Task.FromResult(false);
            }
            else
            {
                await SaveUserAsync(request);
                return await Task.FromResult(true);
            }
        }
    }
}
