﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.Services.Common;

namespace CraftCenter.OregonState.Edu.Services.Responses
{
    public class GetCoursesResponse
    {
        //public string CategoryName { get; set; }

        public int CategoryId { get; set; }

        public string CategoryName { get; set; }

        public string CategoryDescription { get; set; }

        public List<CourseDto> Courses { get; set; }
    }
}