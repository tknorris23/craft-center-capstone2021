﻿using CraftCenter.OregonState.Edu.Services.Common;
using System.Collections.Generic;

namespace CraftCenter.OregonState.Edu.Services.Responses
{
    public class GetAllCourseCategoriesResponse
    {
        //public List<string> Categories { get; set; } = new List<string>();

        public List<CategoryDto> Categories { get; set; } = new List<CategoryDto>();
    }
}
