﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.Services.Common;

namespace CraftCenter.OregonState.Edu.Services.Responses
{
    public class GetScheduleResponse
    {
        public string CourseName { get; set; }

        public List<SectionDto> Sections { get; set; }
    }
}