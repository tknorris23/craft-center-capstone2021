﻿using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.Extensions.Configuration;

namespace CraftCenter.OregonState.Edu.WebUI
{
    public class SettingsProvider : ISettingsProvider
    {
        private readonly IConfiguration configuration;

        private readonly string GoogleClientIdKeyName = "Google:ClientId";
        private readonly string GoogleClientSecretKeyName = "Google:ClientSecret";

        private readonly string DbConnectionStringKey = "DefaultConnection";

        public SettingsProvider(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public string DbConnectionString => configuration.GetConnectionString(DbConnectionStringKey);

        public string GoogleClientId => configuration[GoogleClientIdKeyName];
        
        public string GoogleClientSecret => configuration[GoogleClientSecretKeyName];
        
    }
}