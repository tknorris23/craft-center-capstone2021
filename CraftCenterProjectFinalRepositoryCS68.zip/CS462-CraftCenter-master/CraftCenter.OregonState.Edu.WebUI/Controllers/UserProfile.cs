﻿using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.WebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [Authorize]
    public class UserProfile : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMembershipServices membershipServices;

        public UserProfile(ILogger<HomeController> logger, IMembershipServices membershipServices)
        {
            _logger = logger;
            this.membershipServices = membershipServices;
        }

        public async Task<IActionResult> IndexAsync()
        {
            List<object> list = new List<object>();
            foreach (var UserValues in User.Claims)
            {
                list.Add(UserValues.Value);

            }
            bool memberShipCheck = await membershipServices.CheckMemberShip(User.FindFirstValue(ClaimTypes.NameIdentifier).ToString());
            if (memberShipCheck == false)
            {
                await Response.WriteAsync("<script language='javascript'>window.alert('You need to complete your membership to view this page');window.location='MembershipRegistration';</script>");
                return View();
            }
            else
            {
                Membership getMember = await membershipServices.ReturnMember(User.FindFirstValue(ClaimTypes.NameIdentifier).ToString());
                ViewBag.Message = getMember;
                return View();
            }
     
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

