﻿using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    public class ClassViewController : Controller
    {
        private readonly IEnrollmentServices enrollServices;
        private readonly IMembershipServices memberServices;
        private readonly IClassRegistrationService classServices;

        public ClassViewController(IEnrollmentServices enrollServices, IMembershipServices memberServices, IClassRegistrationService classServices) {
            this.enrollServices = enrollServices;
            this.memberServices = memberServices;
            this.classServices = classServices;
        }
        public async Task<IActionResult> IndexAsync()
        {
            int memberID = await GetMemberIDAsync();
            if (memberID == 0)
            {
                await Response.WriteAsync("<script language='javascript'>window.alert('You need to complete your membership before you can view registered classes');window.location='MembershipRegistration';</script>");
            }
           
            return View();
        }

        public async Task<JsonResult> GetUserEnrollment()
        {
            int memberID = await GetMemberIDAsync();
            /*Enrollment userEnrollment = await enrollServices.getUserEnrollment(memberID);*/
            List<Enrollment> ourList = await enrollServices.getUserEnrollment(memberID);
            return Json(ourList);
        }

        private async Task<int> GetMemberIDAsync()
        {
            string userEmailAddress = User.FindFirstValue(ClaimTypes.NameIdentifier).ToString();
            Membership getMember = await memberServices.ReturnMember(userEmailAddress);
            if (getMember != null)
            {
                return await Task.FromResult(getMember.Id);
            }
            else
            {
                return await Task.FromResult<int>(0);
            }
        }
    }
}
