﻿using AutoMapper;
using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Repository;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;


namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    
    public class CourseRegistrationController : Controller
    {
        private readonly IClassRegistrationService service;
        private readonly IDbUnitOfWork unitOfWork;
        private readonly IClassRegistrationRepository repository;
        private readonly IMembershipServices memberServices;
        private readonly IEnrollmentServices enrollServices;
        public CourseRegistrationController(IClassRegistrationService service, IDbUnitOfWork unitOfWork, IClassRegistrationRepository repository, IMembershipServices memberServices, IEnrollmentServices enrollServices)
        {
            this.service = service;
            this.unitOfWork = unitOfWork;
            this.repository = repository;
            this.memberServices = memberServices;
            this.enrollServices = enrollServices;
        }
        [HttpGet]
        public async Task<IActionResult> IndexAsync()
        {
            //don't let any user access this page until they are a member or an admin
            bool memberShipCheck = await memberServices.CheckMemberShip(User.FindFirstValue(ClaimTypes.NameIdentifier).ToString());
            if (memberShipCheck == false)
            {
                await Response.WriteAsync("<script language='javascript'>window.alert('You need to complete your membership before you can register for classes');window.location='MembershipRegistration';</script>");
                return View();
            }
            else
            {
                var result = await service.GetAllCategories();
                List<Category> categoryList = new List<Category>();
                categoryList.Insert(0, new Category { CategoryId = 0, Name = "Select" });
                foreach (var sourceCategory in result.Categories)
                {
                    categoryList.Add(new Category()
                    {
                        CategoryId = sourceCategory.CategoryId,
                        Name = sourceCategory.Name,
                        Description = sourceCategory.Description
                    });
                }
                ViewBag.ListofCategory = categoryList;
                return View();
            }
         
        }
        public async Task<JsonResult> GetSubCategoryAsync(int CategoryID)
        {
            List<Course> CoursesList = new List<Course>();
            CoursesList.Insert(0, new Course { CourseId = 0, Name = "Select" });
            if (CategoryID == 0)
            {
                return Json(null);
            }
            else
            {
                var result = await service.GetCoursesByCategory(CategoryID);
                foreach (var courseSec in result.Courses)
                {
                    if (courseSec.isActive == true)
                    {
                        CoursesList.Add(new Course()
                        {
                            CategoryId = CategoryID,
                            CourseId = courseSec.CourseId,
                            Code = courseSec.Code,
                            Name = courseSec.Name,
                            Fee = courseSec.Fee,
                            Description = courseSec.Description,
                            LengthInMinutes = courseSec.LengthInMinutes
                        });
                    }
                    
                }
            }
          


            return Json(new SelectList(CoursesList, "CourseId", "Name"));
/*            return Json(result);*/
        }
        public async Task<JsonResult> GetProductsAsync(int CourseId)
        {
            List<Section> SectionList = new List<Section>();
            SectionList.Insert(0, new Section { SectionId = 0, Name = "Select" });
            var sections = await repository.GetSections(CourseId).ToListAsync();

            foreach (var sectionSet in sections)
            {
                SectionList.Add(new Section()
                {
                    SectionId = sectionSet.SectionId,
                    CourseId=  sectionSet.CourseId,
                    Name = sectionSet.Name,
                    Instructor = sectionSet.Instructor,
                    Type = sectionSet.Type,
                    Times = sectionSet.Times,
                    ActualEnrl = sectionSet.ActualEnrl,
                    MaxEnrl = sectionSet.MaxEnrl
                });
                  
            }
            return Json(new SelectList(SectionList, "SectionId", "Name"));
        }

        public async Task<JsonResult> getSectionDetails(int SectionID)
        {
            List<Section> SectionDetail = new List<Section>();
            Section getSingleSection = new Section();
            getSingleSection = await service.findSection(SectionID);
            SectionDetail.Add(getSingleSection);
            return Json(SectionDetail);
        }

        public async Task<JsonResult> getModalDetails(int courseID, int SectionID, int CategoryID)
        {

            //get CategoryID Details
            Category selectCategory = await service.findCategory(CategoryID);
            Course selectedCourse = await service.findCourse(courseID, CategoryID);
            Section selectedSection = await service.findSection(SectionID);

            return Json(new
            {
                CourseName = selectedCourse.Name,
                CourseFees = selectedCourse.Fee,
                CourseLength = selectedCourse.LengthInMinutes,
                policyLink = selectCategory.Description,
                SectionName = selectedSection.Name,
                SectionInstructor = selectedSection.Instructor
            });
        }
        public async Task<JsonResult> RegisterClassEnrollmentAsync(int courseID, int SectionID, int CategoryID)
        {
            bool registered = false;
            Enrollment ourUserEnrollment = new Enrollment();
            string userEmailAddress = User.FindFirstValue(ClaimTypes.NameIdentifier).ToString();
            Membership getMember = await memberServices.ReturnMember(userEmailAddress);
            ourUserEnrollment.Membership = getMember;
            ourUserEnrollment.CategoryID = CategoryID;
            ourUserEnrollment.Category = await service.findCategory(CategoryID);
            ourUserEnrollment.MemberID = getMember.Id;
            ourUserEnrollment.SectionId = SectionID;
            ourUserEnrollment.Section = await service.findSection(SectionID);
            ourUserEnrollment.CourseId = courseID;
            ourUserEnrollment.Course = await service.findCourse(courseID, CategoryID);
            if (ourUserEnrollment.Section.MaxEnrl > ourUserEnrollment.Section.ActualEnrl)
            {
                registered = await enrollServices.CreateEnrollment(ourUserEnrollment);
                await service.updateSectionEnrollVal(SectionID, courseID);
                return Json(new
                {
                    boolval = registered
                });
            }
            else
            {
                return Json(new
                {
                    boolval = "Class is full"
                });
            }



        }
    }

}