﻿using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    public class AddClass : Controller
    {
        private readonly IClassRegistrationService classServices;
        private readonly IEnrollmentServices enrollmentServices;

        public AddClass(IClassRegistrationService classServices, IEnrollmentServices enrollmentServices)
        {
            this.classServices = classServices;
            this.enrollmentServices = enrollmentServices;
        }
        
        public IActionResult Index()
        {
            return View();
        }

        public async Task<JsonResult> addCategoryAsync(string categoryName, string categoryURL)
        {
            if (categoryName != null && categoryURL != null)
            {
                newCategoryRequest newCategory = new newCategoryRequest();
                newCategory.Name = categoryName;
                newCategory.Description = categoryURL;
                newCategory.isActive = true;
                await classServices.addCategory(newCategory);
                return Json(new
                {
                    successfulCategory = true
                });
            }
            else
            {
                return Json(new
                {
                    successfulCategory = false
                });
            }
        }

        public async Task<JsonResult> getAllCategoryAsync()
        {
            var result = await classServices.GetAllCategories();
            List<Category> categoryList = new List<Category>();
            foreach (var sourceCategory in result.Categories)
            {
                categoryList.Add(new Category()
                {
                    CategoryId = sourceCategory.CategoryId,
                    Name = sourceCategory.Name,
                    Description = sourceCategory.Description
                });
            }
            return Json(new SelectList(categoryList, "CategoryId", "Name"));
        }

        public async Task<JsonResult> deleteCategory(int categoryID)
        {
            await classServices.deleteCategory(categoryID);
            return Json(new
            {
                deleteSuccesful = true
            });
        }

        public async Task<JsonResult> addNewCourse(string courseName, int categoryID, int courseFee, int courseLengthInMins, string courseCode, string courseDescription)
        {
            if (courseName != null && categoryID > 0 && courseFee > 0 && courseLengthInMins > 0 && courseCode != null && courseDescription != null)
            {
                newCourseRequest newCourse = new newCourseRequest
                {
                    Name = courseName,
                    CategoryId = categoryID,
                    Fee = courseFee,
                    LengthInMinutes = courseLengthInMins,
                    Code = courseCode,
                    Description = courseDescription,
                    isActive = true
                };
                await classServices.addCourse(newCourse);
                return Json(new
                {
                    succesfulClass = true
                });

            }
            else
            {
                return Json(new
                {
                    succesfulClass = false
                });
            }
        }
        public async Task<JsonResult> GetSubCategory(int CategoryID)
        {
            List<Course> CoursesList = new List<Course>();
            if (CategoryID == 0)
            {
                return Json(null);
            }
            else
            {
                var result = await classServices.GetCoursesByCategory(CategoryID);
                foreach (var courseSec in result.Courses)
                {
                    if (courseSec.isActive == true)
                    {
                        CoursesList.Add(new Course()
                        {
                            CategoryId = CategoryID,
                            CourseId = courseSec.CourseId,
                            Code = courseSec.Code,
                            Name = courseSec.Name,
                            Fee = courseSec.Fee,
                            Description = courseSec.Description,
                            LengthInMinutes = courseSec.LengthInMinutes
                        });}}}
            return Json(new SelectList(CoursesList, "CourseId", "Name"));
        }

        public async Task<JsonResult> getSections(int CourseId)
        {
            List<Section> SectionList = new List<Section>();
            var sections = await classServices.GetSections(CourseId).ToListAsync();
            foreach (var sectionSet in sections)
            {
                SectionList.Add(new Section()
                {
                    SectionId = sectionSet.SectionId,
                    CourseId = sectionSet.CourseId,
                    Name = sectionSet.Name,
                    Instructor = sectionSet.Instructor,
                    Type = sectionSet.Type,
                    Times = sectionSet.Times,
                    ActualEnrl = sectionSet.ActualEnrl,
                    MaxEnrl = sectionSet.MaxEnrl
                });

            }
            return Json(new SelectList(SectionList, "SectionId", "Name"));
        }
            public async Task<JsonResult> disableCourse(int courseID, int categoryID)
        {
            if (courseID > 0 && categoryID > 0)
            {
                await classServices.disableCourse(courseID, categoryID);
                return Json(new
                {
                    disableSuccesful = true
                });
            }
            else
            {
                return Json(new
                {
                    disableSuccesful = false
                });
            }
        }

        public async Task<JsonResult> addNewSection(int CategoryID, int CourseID, string sectionName, string sectionInstructor, string sectionType, string sectionTimes, int sectionMaxEnrl)
        {
            if (CategoryID > 0 && CourseID > 0 && sectionName != null && sectionInstructor != null && sectionType != null && sectionTimes != null && sectionMaxEnrl > 0)
            {
                newSectionRequest newSection = new newSectionRequest()
                {
                    CourseId = CourseID,
                    Name = sectionName,
                    Instructor = sectionInstructor,
                    Type = sectionType,
                    Times = sectionTimes,
                    ActualEnrl = 0,
                    isActive = true,
                    MaxEnrl = sectionMaxEnrl
                };
                await classServices.addSection(newSection);
                return Json(new
                {
                    addSectionSuccessful = true
                });
            }
            else
            {
                return Json(new
                {
                    addSectionSuccessful = false
                });
            }
        }

        public async Task<JsonResult> disableSection(int courseID, int categoryID, int sectionID)
        {
            if (courseID > 0 && categoryID > 0 && sectionID > 0)
            {
                await classServices.disableSection(courseID, categoryID, sectionID);
                return Json(new { disableSectionSuccesful = true});
            }
            else
            {
                return Json(new { disableSectionSuccesful = false });
            }
        }

        public JsonResult GetEnrollmentbySection(int sectionID, int courseID, int categoryID)
        {
            List<Enrollment> enrollListbySection = new List<Enrollment>();
            var result = enrollmentServices.getEnrollmentsbySection(sectionID, courseID, categoryID);
            if (result != null)
            {
                return Json(result);
            }
            else
            {
                return Json(result);
            }
        }
        public async Task<JsonResult> getCategoryDetails(int categoryID)
        {
            Category selectedCategory = await classServices.findCategory(categoryID);
            if (selectedCategory != null)
            {
                return Json(selectedCategory);
            }
            else
            {
                return Json(null);
            }
        }

        public async Task<JsonResult> editCategorySet(int categoryID, string categoryName, string categoryDescription)
        {
            Category selectedCategory = await classServices.findCategory(categoryID);
            if (categoryName != null && categoryDescription != null)
            {
                if (selectedCategory.Name != categoryName && selectedCategory.Description != categoryDescription)
                {
                    await classServices.updateCategory(categoryID, categoryName, categoryDescription);
                    return Json(new { UpdateCategorySuccess = true });
                }
            }
            return Json(new { UpdateCategorySuccess = false});
        }

        public async Task<JsonResult> getCourseDetails(int categoryID, int courseID)
        {
            Course selectedCourse = await classServices.findCourse(courseID, categoryID);
            if (selectedCourse != null)
            {
                return Json(selectedCourse);
            }
            return Json(null);
        }

        public async Task<JsonResult> EditCourseSet(int categoryID, int courseID, string courseName, int courseFee, int courseLengthInMins, string courseCode, string courseDescription)
        {
            Course selectedCourse = await classServices.findCourse(courseID, categoryID);

            if (selectedCourse != null)
            {
                await classServices.updateCourse(categoryID, courseID, courseName, courseFee, courseLengthInMins, courseCode, courseDescription);

               return  Json(new { UpdateCourseSuccess = true });
            }
            return Json(new { UpdateCourseSuccess = false });
        }

        public async Task<JsonResult> getSectionDetails(int SectionID)
        {
            Section getSingleSection = new Section();
            getSingleSection = await classServices.findSection(SectionID);
            return Json(getSingleSection);
        }

        public async Task<JsonResult> EditSectionSet(int courseID, int sectionID, string sectionName, string instructor, string type, string time, int maxEnrollment)
        {
            Section getSingleSection = new Section();
            getSingleSection = await classServices.findSection(sectionID);
            if (getSingleSection != null)
            {
                await classServices.updateSection(courseID, sectionID, sectionName, instructor, type, time, maxEnrollment);
                return Json(new { UpdateSectionSuccess = true });
            }
            return Json(new { UpdateSectionSuccess = false });
        }

        public JsonResult GetDisabledCategories()
        {
            var result = classServices.getDisabledCategories();
            List<Category> categoryList = new List<Category>();
            foreach (var sourceCategory in result)
            {
                categoryList.Add(new Category()
                {
                    CategoryId = sourceCategory.CategoryId,
                    Name = sourceCategory.Name,
                    Description = sourceCategory.Description
                });
            }
            return Json(new SelectList(categoryList, "CategoryId", "Name"));
        }
        public async Task<JsonResult> enableCategory(int categoryID)
        {
            if (categoryID > 0)
            {
                await classServices.enableCategory(categoryID);
                return Json(new
                {
                    enableCategory = true
                });
            }
            return Json(new
            {
                enableCategory = false
            });

        }
        public JsonResult GetDisabledCourses(int CategoryID)
        {
            List<Course> CoursesList = new List<Course>();
            if (CategoryID == 0)
            {
                return Json(null);
            }
            else
            {
                var result = classServices.getDisabledCourses(CategoryID);
                foreach (var courseSec in result)
                {
                        CoursesList.Add(new Course()
                        {
                            CategoryId = CategoryID,
                            CourseId = courseSec.CourseId,
                            Code = courseSec.Code,
                            Name = courseSec.Name,
                            Fee = courseSec.Fee,
                            Description = courseSec.Description,
                            LengthInMinutes = courseSec.LengthInMinutes
                        });
                }
            }
            return Json(new SelectList(CoursesList, "CourseId", "Name"));
        }
        public async Task<JsonResult> enableCourse(int courseID, int categoryID)
        {
            if (courseID > 0 && categoryID > 0)
            {
                await classServices.enableCourse(courseID, categoryID);
                return Json(new
                {
                    enableSuccesful = true
                });
            }
            else
            {
                return Json(new
                {
                    enableSuccesful = false
                });
            }
        }
        public JsonResult getDisabledSections(int CourseId)
        {
            List<Section> SectionList = new List<Section>();
            var sections = classServices.getDisabledSections(CourseId);
            foreach (var sectionSet in sections)
            {
                SectionList.Add(new Section()
                {
                    SectionId = sectionSet.SectionId,
                    CourseId = sectionSet.CourseId,
                    Name = sectionSet.Name,
                    Instructor = sectionSet.Instructor,
                    Type = sectionSet.Type,
                    Times = sectionSet.Times,
                    ActualEnrl = sectionSet.ActualEnrl,
                    MaxEnrl = sectionSet.MaxEnrl
                });

            }
            return Json(new SelectList(SectionList, "SectionId", "Name"));
        }
        public async Task<JsonResult> enableSection(int courseID, int categoryID, int sectionID)
        {
            if (courseID > 0 && categoryID > 0 && sectionID > 0)
            {
                await classServices.enableSection(courseID, categoryID, sectionID);
                return Json(new { enableSectionSuccesful = true });
            }
            else
            {
                return Json(new { enableSectionSuccesful = false });
            }
        }

    }
}

