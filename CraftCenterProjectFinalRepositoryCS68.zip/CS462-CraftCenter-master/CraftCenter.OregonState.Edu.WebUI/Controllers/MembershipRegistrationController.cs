﻿using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using CraftCenter.OregonState.Edu.WebUI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;


namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [Authorize]
    public class MembershipRegistration : Controller
    {
        private readonly IMembershipServices membershipServices;
        public MembershipRegistration(IMembershipServices membershipServices)
        {
            this.membershipServices = membershipServices;
        }
        [HttpGet]
        public async Task<ActionResult> IndexAsync()
        {


            List<object> list = new List<object>();
            foreach (var UserValues in User.Claims)
            {
                list.Add(UserValues.Value);

            }

            bool checkMember = await membershipServices.CheckMemberShip(list[0].ToString());
            if (checkMember == true)
            {
                Response.Redirect("/CourseRegistration");
            }
            else
            {
                return View();
            }
            return View();

        }
        [HttpPost]
        public async Task<ActionResult> IndexAsync(NewMembershipRequest members)
        {
            ViewBag.FirstName = members.FirstName;
            ViewBag.LastName = members.LastName;
            ViewBag.TypeRegistration = members.TypeRegistration;
            members.RegistrationDate = DateTime.Now.ToString();
            await membershipServices.CreateMembership(members);

            Response.Redirect("/CourseRegistration");
            return View("Index");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}