﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using ITfoxtec.Identity.Saml2;
using ITfoxtec.Identity.Saml2.Schemas;
using System.Diagnostics;
using ITfoxtec.Identity.Saml2.MvcCore;
using System.Security.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Authorization;
using CraftCenter.OregonState.Edu.WebUI.Identity;
using System.Security.Claims;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using CraftCenter.OregonState.Edu.DataAccessClass;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [AllowAnonymous]
    [Route("Auth")]
    public class AuthController : Controller
    {
        const string relayStateReturnUrl = "ReturnUrl";
        private readonly Saml2Configuration config;
        private readonly IUserService userService;
        public AuthController(IOptions<Saml2Configuration> configAccessor, IUserService userService)
        {
            config = configAccessor.Value;
            this.userService = userService;
        }

        [Route("Login")]
        public IActionResult Login(string returnUrl = null)
        {
            var binding = new Saml2RedirectBinding();
            binding.SetRelayStateQuery(new Dictionary<string, string> { { relayStateReturnUrl, returnUrl ?? Url.Content("~/") } });

            var testBinding = binding.Bind(new Saml2AuthnRequest(config)
            { }).ToActionResult();
            return testBinding;
        }

        [Route("AssertionConsumerService")]
        public async Task<IActionResult> AssertionConsumerService()
        {
            var binding = new Saml2PostBinding();
            var saml2AuthnResponse = new Saml2AuthnResponse(config);

            binding.ReadSamlResponse(Request.ToGenericHttpRequest(), saml2AuthnResponse);
            if (saml2AuthnResponse.Status != Saml2StatusCodes.Success)
            {
                throw new AuthenticationException($"SAML Response status: {saml2AuthnResponse.Status}");
            }
            binding.Unbind(Request.ToGenericHttpRequest(), saml2AuthnResponse);
            await saml2AuthnResponse.CreateSession(HttpContext, claimsTransform: (claimsPrincipal) => ClaimsTransform.Transform(claimsPrincipal));
            var relayStateQuery = binding.GetRelayStateQuery();
            var returnUrl = relayStateQuery.ContainsKey(relayStateReturnUrl) ? relayStateQuery[relayStateReturnUrl] : Url.Content("~/");
            return Redirect("SignedIn");
        }

        [HttpPost("Logout")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return Redirect(Url.Content("~/"));
            }

            var binding = new Saml2PostBinding();
            var saml2LogoutRequest = await new Saml2LogoutRequest(config, User).DeleteSession(HttpContext);
            binding.Bind(saml2LogoutRequest);
            return Redirect(Url.Content("~/"));
        }

        [Route("LoggedOut")]
        public async Task<IActionResult> LoggedOutAsync()
        {
            var binding = new Saml2PostBinding();
            binding.Unbind(Request.ToGenericHttpRequest(), new Saml2LogoutResponse(config));
            var saml2LogoutRequest = await new Saml2LogoutRequest(config, User).DeleteSession(HttpContext);
            return Redirect(Url.Content("~/"));
        }
        [Route("SignedIn")]
        public async Task<IActionResult> SignedIn()
        {
            var request = new NewUserRequest();
            var UserClaimTypes = User.Claims.Select(claim => new { claim.Type, claim.Value }).ToArray();
            foreach (var UserValue in UserClaimTypes)
            {
               if (UserValue.Type.Contains("urn:oid:2.5.4.3"))
                {
                    string Nametype = UserValue.Value.ToString();
                    string[] breakName = Nametype.Split(',');
                    string FullName = breakName[1] + " " + breakName[0];
                    FullName = FullName.Trim();
                    request.Name = FullName;
                }
               else if (UserValue.Type.Contains("nameidentifier"))
                {
                    request.EmailAddress = UserValue.Value.ToString();
                    request.ClaimIdentifier = UserValue.Value.ToString();
                }

            }
            request.Issuer = "OSU";
            request.UserRole = "Student";
               
            bool InsertUser = await userService.CheckUser(request);

            Response.Redirect("/MembershipRegistration");
            return Redirect(Url.Content("/MembershipRegistration"));

        }
    }
}