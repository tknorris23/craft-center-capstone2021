﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Facebook;
using CraftCenter.OregonState.Edu.WebUI.DataAccessLayer;
using Microsoft.Extensions.Configuration;
using CraftCenter.OregonState.Edu.WebUI.Models;
using System.Security.Claims;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [AllowAnonymous, Route("account")]
    public class AccountController : Controller
    {
        private readonly IUserService userService;

        public AccountController(IUserService userService)
        {
            this.userService = userService;
        }

        AccountDB SetupAccount = new AccountDB();
        [Route("google-login")]
        public IActionResult GoogleLogin()
        {
            var AccountProperties = new AuthenticationProperties { RedirectUri = Url.Action("GoogleResponse") };

            return Challenge(AccountProperties, GoogleDefaults.AuthenticationScheme);
        }

        [Route("google-response")]
        public async Task<IActionResult> GoogleResponse()
        {
            var result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var userClaims = result.Principal.Identities.FirstOrDefault()
                .Claims.Select(UserClaims => new
                {
                    UserClaims.Issuer,
                    UserClaims.OriginalIssuer,
                    UserClaims.Type,
                    UserClaims.Value

                }
                );

            var request = new NewUserRequest
            {
                Issuer = "Google",
                UserRole = "Student",
                Name = userClaims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value,
                EmailAddress = userClaims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value,
                ClaimIdentifier = userClaims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value
            };

            await userService.SaveUserAsync(request);

            Response.Redirect("/MembershipRegistration");
            return Json(userClaims);
        }

        [Route("facebook-login")]
        public IActionResult FacebookLogin()
        {
            var AccountProperties = new AuthenticationProperties { RedirectUri = Url.Action("FacebookResponse") };

            return Challenge(AccountProperties, FacebookDefaults.AuthenticationScheme);
        }
        [Route("facebook-response")]
        public async Task<IActionResult> FacebookResponse()
        {
            var result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var UserClaims = result.Principal.Identities.FirstOrDefault()
                .Claims.Select(UserClaims => new
                {
                    UserClaims.Issuer,
                    UserClaims.OriginalIssuer,
                    UserClaims.Type,
                    UserClaims.Value

                }
                );
            return Json(UserClaims);
        }


    }

}