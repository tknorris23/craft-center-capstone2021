﻿using CraftCenter.OregonState.Edu.WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [Route("admin")]
    public class AdminController : Controller
    {
        private DataContext db = new DataContext();

        [Route("")]
        [Route("index")]
        ////[Route("~/")]
        public IActionResult Index()
        {
            ViewBag.members = db.Memberships.ToList();
            return View();
        }

        private readonly IMembershipServices membershipServices;
       
        public AdminController(IMembershipServices membershipServices)
        {
            this.membershipServices = membershipServices;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [Route("Error")]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost, ActionName("Delete")]
        [Route("Delete")]
        public IActionResult Delete(string id)
        {
            var user = db.Memberships.Where(a => a.EmailAddress == id).FirstOrDefault();
            db.Memberships.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [Route("Edit")]
        public ActionResult Edit(string Id)
        {
            var view = db.Memberships.Where(s => s.EmailAddress == Id).FirstOrDefault();

            return View(view);
        }

        [HttpPost, ValidateAntiForgeryToken]
        [Route("Index")]
        public ActionResult EditPost(Domain.Model.Membership user)
        {
            var member = db.Memberships.Where(s => s.EmailAddress == user.EmailAddress).FirstOrDefault();
            db.Memberships.Remove(member);
            db.Memberships.Add(user);
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
