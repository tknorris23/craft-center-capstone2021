﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Models
{
    public class CourseListViewModel
    {
        public string CategoryName { get; set; }

        public IEnumerable<CourseViewModel> Courses { get; set; }
    }
}
