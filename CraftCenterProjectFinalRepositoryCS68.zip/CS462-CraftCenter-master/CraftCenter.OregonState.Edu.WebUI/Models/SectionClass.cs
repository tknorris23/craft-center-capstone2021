﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Models
{
    public class SectionClass
    {
        public string Type { get; set; }
        
        public string Time { get; set; }
        
        public string Instructor { get; set; }
        
        public string SeatsFilled { get; set; }
        
        public string Status { get; set; }
    }
}
