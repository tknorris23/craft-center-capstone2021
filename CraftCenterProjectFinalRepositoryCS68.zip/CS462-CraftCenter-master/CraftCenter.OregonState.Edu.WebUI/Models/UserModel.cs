﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Models
{
    public class UserModel
    {

		/*     @in_Name nvarchar(50),
		 @in_UID nvarchar(255),
		 @in_Email nvarchar(50),
		 @in_Issuer nvarchar(50),
		 @in_UserRole nvarchar(10)*/
		public string Name { get; set; }

		public string UID { get; set; }

		public string Issuer { get; set; }

		public string EmailAddress { get; set; }

		public string UserRole { get; set; }


	}
}
