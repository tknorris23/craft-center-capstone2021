﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Models
{
    public class CourseScheduleViewModel
    {
        public string CourseName { get; set; }

        public IEnumerable<SectionClass> Sections { get; set; }
    }
}
